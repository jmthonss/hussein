#ifndef XT_OFFSETS2_H
#define XT_OFFSETS2_H

namespace OffsetsAllBt64 {
	uint32_t kTargetFuncShellCode[11] = {0x10000100,
                                         0xBD400003,
                                         0xBD400404,
                                         0xBD400805,
                                         0x4EA31C60,
                                         0x4EA41C81,
                                         0x4EA51CA2,
                                         0xD65F03C0,
                                         0x00000000, 0x00000000, 0x00000000};
    uint32_t kTargetFuncOrigCode[11] ={};                 
    uint32_t BypassBT_patch[2] = {0x910003FF, 0x8A010021};
    uint32_t BypassBT_orig[2]={};
    uintptr_t ps_ShellCode_Aim3DPosition = 0;
    uintptr_t ps_Global_TargetFunc = 0;
    uintptr_t ps_Global_Patch1 = 0;
    uintptr_t ps_ASTExtraCharacter_PartHitComponent =0;
	// PartHitComponent* PartHitComponent;//[Offset:
    uintptr_t ps_UPartHitComponent_ConfigCollisionDistSqAngles =0;
	// OpenCollisionLODAngle[] ConfigCollisionDistSqAngles;//[Offset:
	
	void GameType64(int a){
	
		if(a == 1) {
			uint32_t sori[11] = {0xD10703FF,0xFD00B3EA,0x6D16A3E9,0xA917FBFD,0xF900C7FC,0xA9195FF8,0xA91A57F6,0xA91B4FF4,0x9105E3FD,0xAA0003F3,0xF9410800};
            uint32_t bori[2] = {0xBD002BE2, 0x97E03098};
			std::copy(bori, bori + 2, BypassBT_orig);
			std::copy(sori, sori + 11, kTargetFuncOrigCode);
            ps_ShellCode_Aim3DPosition = 0x20;
            ps_Global_TargetFunc = 0x58F8B58;
            ps_Global_Patch1 = 0x592A5A8;
			ps_ASTExtraCharacter_PartHitComponent = 0x1028;
            ps_UPartHitComponent_ConfigCollisionDistSqAngles =0x198;
		} else if(a == 2) {
			uint32_t sori[11] = {0xD10703FF,0xFD00B3EA,0x6D16A3E9,0xA917FBFD,0xF900C7FC,0xA9195FF8,0xA91A57F6,0xA91B4FF4,0x9105E3FD,0xAA0003F3,0xF9410800};
            uint32_t bori[2] = {0xBD002BE2, 0x97E03098};
			std::copy(bori, bori + 2, BypassBT_orig);
			std::copy(sori, sori + 11, kTargetFuncOrigCode);
            ps_ShellCode_Aim3DPosition = 0x20;
            ps_Global_TargetFunc = 0x58F8B58;
            ps_Global_Patch1 = 0x592A5A8;
			ps_ASTExtraCharacter_PartHitComponent = 0x1028;
            ps_UPartHitComponent_ConfigCollisionDistSqAngles =0x198;
		} else if(a==3) {
			uint32_t sori[11] = {0x6DB92BEB, 0x6D0123E9, 0xA9026FFC, 0xA9035FF8, 0xA90457F6, 0xA9054FF4, 0xA9067BFD, 0x910183FD, 0xD10583FF, 0xAA0003F3, 0xF9411260};
            uint32_t bori[2] = {0xBD00EBE2, 0x97DE8878};
			std::copy(bori, bori + 2, BypassBT_orig);
			std::copy(sori, sori + 11, kTargetFuncOrigCode);
            ps_ShellCode_Aim3DPosition = 0x20;
            ps_Global_TargetFunc = 0x5edb3f0;
            ps_Global_Patch1 = 0x5f0e244;
			ps_ASTExtraCharacter_PartHitComponent = 0x1020;
            ps_UPartHitComponent_ConfigCollisionDistSqAngles =0x198;
		}
	}
}


namespace OffsetsAllBt32 {
	uint32_t kTargetFuncShellCode[10] = {0xe59f1014, 0xe59f2014, 0xe59f3014, 0xe5801000,
                                         0xe5802004, 0xe5803008, 0xe12fff1e, 0x00000000,
                                         0x00000000, 0x00000000};
    uint32_t BypassBT_patch[2] = {0xE22DD000,0xE3CDD000};
	uint32_t BypassBT_patch2 = 0xE28D00F0;
	
    uint32_t BypassBT_orig[2]={};
	uint32_t kTargetFuncOrigCode[10] ={};
	uint32_t BypassBT_orig2 = 0;
    uintptr_t ps_ShellCode_Aim3DPosition = 0;
    uintptr_t ps_Global_TargetFunc = 0;
    uintptr_t ps_Global_Patch1 = 0;
	uintptr_t ps_Global_Patch2 = 0;
    uintptr_t ps_ASTExtraCharacter_PartHitComponent =0;
    uintptr_t ps_UPartHitComponent_ConfigCollisionDistSqAngles =0;
    
	void GameType32(int a){
		if(a == 1) {
			uint32_t sori[10] = {0xE92D4FF0, 0xE28DB01C, 0xE24DD004, 0xED2D8B02, 0xE24DDE15, 0xE1A05001, 0xE1A08000, 0xE59501A4, 0xE1A04003, 0xE1A09002};
            uint32_t bori[2] = {0xE1A02007,0xEBDC040E};
			std::copy(bori, bori + 2, BypassBT_orig);
			std::copy(sori, sori + 10, kTargetFuncOrigCode);
			BypassBT_orig2 = 0xE1A00007;
			
            ps_ShellCode_Aim3DPosition = 0x1c;
            ps_Global_TargetFunc = 0x3415d64;
            ps_Global_Patch1 = 0x344e750;
			ps_Global_Patch2 = 0x344e73c;
			ps_ASTExtraCharacter_PartHitComponent = 0xbe4;
            ps_UPartHitComponent_ConfigCollisionDistSqAngles =0x120;
 
		} else if(a == 2) {
			uint32_t sori[10] = {0xE92D4FF0, 0xE28DB01C, 0xE24DD004, 0xED2D8B02, 0xE24DDE15, 0xE1A05001, 0xE1A08000, 0xE59501A4, 0xE1A04003, 0xE1A09002};
            uint32_t bori[2] = {0xE1A02007,0xEBDC0C8A};
			std::copy(bori, bori + 2, BypassBT_orig);
			std::copy(sori, sori + 10, kTargetFuncOrigCode);
			BypassBT_orig2 = 0xE1A00007;
			
            ps_ShellCode_Aim3DPosition = 0x1c;
            ps_Global_TargetFunc = 0x3316cb4;
            ps_Global_Patch1 = 0x334f6a0;
			ps_Global_Patch2 = 0x334f68c;
			ps_ASTExtraCharacter_PartHitComponent = 0xbe4;
            ps_UPartHitComponent_ConfigCollisionDistSqAngles =0x120;
            
		} else {
			uint32_t sori[10] = {0xE92D4FF0, 0xE28DB01C, 0xE24DD004, 0xED2D8B02, 0xE24DDE15, 0xE1A05001, 0xE1A08000, 0xE59501A4, 0xE1A04003, 0xE1A09002};
            uint32_t bori[2] = {0xE1A02007,0xEBDC1557};
			std::copy(bori, bori + 2, BypassBT_orig);
			std::copy(sori, sori + 10, kTargetFuncOrigCode);
			BypassBT_orig2 = 0xE1A00007;
			
            ps_ShellCode_Aim3DPosition = 0x1c;
            ps_Global_TargetFunc = 0x3403dc4;
            ps_Global_Patch1 = 0x343c7c0;
			ps_Global_Patch2 = 0x343c7ac;
			ps_ASTExtraCharacter_PartHitComponent = 0xbe4;
            ps_UPartHitComponent_ConfigCollisionDistSqAngles =0x120;
		}
	}
}



#endif //XT_OFFSETS2_H


