/**************************
 * BUILD ON You have no income 😹
 * TELEGRAM : @ABU_FAHAD3
 * *************************/
 
#include "INCLUDE/support.h"
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <thread>
#include "oxorany.cpp"
#include "INCLUDE/obfuscate.h"



#define LOADER_PACKAGE "pubgm.loader" 

#define EXPIRY_YEAR 2026
#define EXPIRY_MONTH 10
#define EXPIRY_DAY 10


#define SECURITY_KEY "001"

/* 
   ==========================@ABU_FAHAD3===============================
*/

int handle;
typedef int8_t BYTE;

// دالة التحقق من وقت الانتهاء
bool is_expired() {
    time_t t = time(NULL);
    struct tm *now = localtime(&t);
    if ((now->tm_year + 1900) > EXPIRY_YEAR) return true;
    if ((now->tm_year + 1900) == EXPIRY_YEAR) {
        if ((now->tm_mon + 1) > EXPIRY_MONTH) return true;
        if ((now->tm_mon + 1) == EXPIRY_MONTH) {
            if (now->tm_mday > EXPIRY_DAY) return true;
        }
    }
    return false;
}

// دالة للحصول على اسم الحزمة من الـ PID
void get_package_name_by_pid(int pid, char* out_name, size_t size) {
    char path[64];
    snprintf(path, sizeof(path), OBFUSCATE("/proc/%d/cmdline"), pid);
    FILE* fp = fopen(path, OBFUSCATE("r"));
    if (fp) {
        fgets(out_name, size, fp);
        fclose(fp);
    }
}

long int get_module_base(int pid, const char *module_name) {
    FILE *fp;
    long addr = 0;
    char filename[64];
    char line[1024];
    
    snprintf(filename, sizeof(filename), OBFUSCATE("/proc/%d/maps"), pid);
    fp = fopen(filename, OBFUSCATE("r"));
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, module_name)) {
                sscanf(line, OBFUSCATE("%lx-%*lx %*s %*s %*s %*d"), &addr);
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}

int getPID(const char *packageName) {
    DIR *dir = opendir(OBFUSCATE("/proc"));
    struct dirent *ptr;
    FILE *fp;
    char filepath[256];
    char filetext[128];
    
    if (!dir) return 0;
    
    while ((ptr = readdir(dir)) != NULL) {
        if (ptr->d_type != DT_DIR) continue;
        snprintf(filepath, sizeof(filepath), OBFUSCATE("/proc/%s/cmdline"), ptr->d_name);
        fp = fopen(filepath, OBFUSCATE("r"));
        if (fp) {
            fgets(filetext, sizeof(filetext), fp);
            fclose(fp);
            if (strcmp(filetext, packageName) == 0) {
                closedir(dir);
                return atoi(ptr->d_name);
            }
        }
    }
    closedir(dir);
    return 0;
}

long int ReadValue(long int addr) {
    long int var = 0;
    if (handle == -1) {
        return 0;
    }
    ssize_t bytesRead = pread64(handle, &var, sizeof(var), addr);
    if (bytesRead != sizeof(var)) {
        return 0;
    }
    return var;
}

float WriteAddress_FLOAT(long int addr, float value) {
    pwrite64(handle, &value, 4, addr);
    return 0;
}

int ABUFAHAD_BaseAddress_FLOAT(long int addr, float value) {
    pwrite64(handle, &value, 4, addr);
    return 0;
}

int ABUFAHAD_BaseAddress_DWORD(long int addr, int value) {
    pwrite64(handle, &value, 4, addr);
    return 0;
}

int EDIT_HEX(long int addr, BYTE* hex_value, int size) {
    return pwrite64(handle, hex_value, size, addr);
}

void edithex(long int address, const char* hex_value) {
    int hex_len = strlen(hex_value) / 3 + 1;
    BYTE* hex_bytes = (BYTE*)malloc(hex_len);
    
    for (int i = 0; i < hex_len; i++) {
        unsigned int byte_val;
        sscanf(&hex_value[i * 3], OBFUSCATE("%2x"), &byte_val);
        hex_bytes[i] = (BYTE)byte_val;
    }
    
    EDIT_HEX(address, hex_bytes, hex_len);
    free(hex_bytes);
}

int main(int argc, char **argv) {
    // --- إضافات الحماية المطلوبة (بدون تغيير الكود الأصلي) ---
    if (argc < 2) return 1;
    
    // 1. تحقق كود الحماية
    bool key_valid = false;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], OBFUSCATE(SECURITY_KEY)) == 0) {
            key_valid = true;
            break;
        }
    }
    if (!key_valid) return 1;

    // 2. تحقق تاريخ الانتهاء
    if (is_expired()) return 1;

    // 3. تحقق اسم حزمة اللودر (تطبيقك)
    pid_t ppid = getppid();
    char parent_name[256] = {0};
    get_package_name_by_pid(ppid, parent_name, sizeof(parent_name));
    // ملاحظة: يمكنك تفعيل السطر التالي بعد كتابة اسم حزمتك في LOADER_PACKAGE
    // if (strcmp(parent_name, OBFUSCATE(LOADER_PACKAGE)) != 0) return 1;
    // -------------------------------------------------------

    int Features = atoi(argv[1]);

    // Detect running package
    int ipid = getPID(OBFUSCATE("com.tencent.ig"));
    const char* runningPackage = nullptr;
    if (ipid != 0) runningPackage = OBFUSCATE("com.tencent.ig");
    else if ((ipid = getPID(OBFUSCATE("com.pubg.krmobile"))) != 0) runningPackage = OBFUSCATE("com.pubg.krmobile");
    else if ((ipid = getPID(OBFUSCATE("com.rekoo.pubgm"))) != 0) runningPackage = OBFUSCATE("com.rekoo.pubgm");
    else if ((ipid = getPID(OBFUSCATE("com.vng.pubgmobile"))) != 0) runningPackage = OBFUSCATE("com.vng.pubgmobile");
    else if ((ipid = getPID(OBFUSCATE("com.pubg.imobile"))) != 0) runningPackage = OBFUSCATE("com.pubg.imobile");

    if (ipid == 0) {
        exit(1);
    }
    
    char lj[64];
    sprintf(lj, OBFUSCATE("/proc/%d/mem"), ipid);
    handle = open(lj, O_RDWR);
    if (handle == -1) {
        exit(1);
    }
    
    long int libanogs = get_module_base(ipid, OBFUSCATE("libanogs.so"));
    long int gcloud = get_module_base(ipid, OBFUSCATE("libgcloud.so"));
    long int hdmv = get_module_base(ipid, OBFUSCATE("libhdmpve.so"));
    long int ue4 = get_module_base(ipid, OBFUSCATE("libUE4.so"));

    switch (Features) {
        case 1:
            close(handle);
            break;

        case 001: {
            edithex(libanogs + oxorany(0x75FE30), OBFUSCATE("20 00 80 52 C0 03 5F D6"));
            edithex(libanogs + oxorany(0x25CB44), OBFUSCATE("00 00 80 D2 C0 03 5F D6"));
            edithex(libanogs + oxorany(0x373064), OBFUSCATE("1F 20 03 D5"));
            edithex(libanogs + oxorany(0x47e34c), OBFUSCATE("C0 03 5F D6"));
            edithex(libanogs + oxorany(0x4b30b8), OBFUSCATE("C0 03 5F D6"));
            edithex(libanogs + oxorany(0x4d8c0c), OBFUSCATE("C0 03 5F D6"));
            edithex(libanogs + oxorany(0x46efd0), OBFUSCATE("00 00 80 52"));
            edithex(libanogs + oxorany(0x46efd4), OBFUSCATE("C0 03 5F D6"));
            edithex(libanogs + oxorany(0x37fd78), OBFUSCATE("C0 03 5F D6"));
            edithex(libanogs + oxorany(0x49aa48), OBFUSCATE("09 00 40 39"));
            edithex(libanogs + oxorany(0x49abe4), OBFUSCATE("6A 02 40 39"));
            edithex(libanogs + oxorany(0x333768), OBFUSCATE("20 00 80 52"));
            edithex(libanogs + oxorany(0x33376c), OBFUSCATE("C0 03 5F D6"));
            edithex(libanogs + oxorany(0x213f88), OBFUSCATE("20 00 80 52"));
            edithex(libanogs + oxorany(0x2142e0), OBFUSCATE("C0 03 5F D6"));
            edithex(libanogs + oxorany(0x362a00), OBFUSCATE("1F 20 03 D5"));
            
            // New Rights format as requested in the image
            puts("************************************");
            puts("  عمك ابوفهد اذكر المصدر   ");
            puts("************************************");
            
            close(handle);
            break;
        }

        case 5:
            ABUFAHAD_BaseAddress_DWORD(gcloud + oxorany(0x421164), oxorany(0));
            close(handle);
            break;

        case 6:
            ABUFAHAD_BaseAddress_DWORD(gcloud + oxorany(0x421164), oxorany(-1326110034));
            close(handle);
            break;

        default:
            close(handle);
            break;
    }

    return 0;
}
//@ABU_FAHAD3